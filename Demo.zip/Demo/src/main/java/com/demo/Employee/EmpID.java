package com.demo.Employee;

public class EmpID {

	private String employeeid;

	public String getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(String employeeid) {
		this.employeeid = employeeid;
	}
	
}
